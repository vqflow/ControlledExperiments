SELECT *
FROM   (SELECT cpnt_typ_id,
               cpnt_id,
               rev_dte,
               cpnt_title,
               rtyp_desc,
               req_dte,
               ?                         AS preferred_timezone,
               Row_number ()
                 over (
                   PARTITION BY cpnt_typ_id, cpnt_id, rev_dte
                   ORDER BY req_dte ASC) row_num
        FROM   (SELECT sqc.stud_id,
                       sqc.cpnt_typ_id,
                       sqc.cpnt_id,
                       sqc.rev_dte,
                       c.cpnt_title,
                       sqc.req_dte,
                       r.rtyp_desc
                FROM   pa_stud_qual_cpnt sqc,
                       pv_course c,
                       pa_rqmt_type r
                WHERE  sqc.cpnt_typ_id = c.cpnt_typ_id
                       AND sqc.cpnt_id = c.cpnt_id
                       AND sqc.rev_dte = c.rev_dte
                       AND sqc.rtyp_id = r.rtyp_id(+)
                       AND sqc.stud_id = ?
                       AND ( sqc.compl_dte IS NULL
                              OR current_date > sqc.exp_dte
                              OR sqc.retrng_int > 0 )
                UNION
                SELECT sc.stud_id,
                       sc.cpnt_typ_id,
                       sc.cpnt_id,
                       sc.rev_dte,
                       c.cpnt_title,
                       sc.req_dte,
                       r.rtyp_desc
                FROM   pv_stud_course sc,
                       pv_course c,
                       pa_rqmt_type r
                WHERE  sc.cpnt_typ_id = c.cpnt_typ_id
                       AND sc.cpnt_id = c.cpnt_id
                       AND sc.rev_dte = c.rev_dte
                       AND sc.rtyp_id = r.rtyp_id(+)
                       AND sc.stud_id = ?
                       AND sc.compl_dte IS NULL))
WHERE  row_num = 1